﻿namespace CalculatorApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tableLayoutPanel1 = new TableLayoutPanel();
            equalbtn = new Button();
            commabtn = new Button();
            zerobtn = new Button();
            negatebtn = new Button();
            plusbtn = new Button();
            threebtn = new Button();
            twobtn = new Button();
            onebtn = new Button();
            minusbtn = new Button();
            sixbtn = new Button();
            fivebtn = new Button();
            fourbtn = new Button();
            multiplicationbtn = new Button();
            ninebtn = new Button();
            eightbtn = new Button();
            sevenbtn = new Button();
            dividebtn = new Button();
            sqrtbtn = new Button();
            byThePowerOf2Btn = new Button();
            XDividedBy1Btn = new Button();
            removeLastOnebtn = new Button();
            removeAllbtn = new Button();
            removeLastbtn = new Button();
            resulttxt = new TextBox();
            percentbtn = new Button();
            placeHolderLabelOfScreen = new Label();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 4;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel1.Controls.Add(equalbtn, 3, 6);
            tableLayoutPanel1.Controls.Add(commabtn, 2, 6);
            tableLayoutPanel1.Controls.Add(zerobtn, 1, 6);
            tableLayoutPanel1.Controls.Add(negatebtn, 0, 6);
            tableLayoutPanel1.Controls.Add(plusbtn, 3, 5);
            tableLayoutPanel1.Controls.Add(threebtn, 2, 5);
            tableLayoutPanel1.Controls.Add(twobtn, 1, 5);
            tableLayoutPanel1.Controls.Add(onebtn, 0, 5);
            tableLayoutPanel1.Controls.Add(minusbtn, 3, 4);
            tableLayoutPanel1.Controls.Add(sixbtn, 2, 4);
            tableLayoutPanel1.Controls.Add(fivebtn, 1, 4);
            tableLayoutPanel1.Controls.Add(fourbtn, 0, 4);
            tableLayoutPanel1.Controls.Add(multiplicationbtn, 3, 3);
            tableLayoutPanel1.Controls.Add(ninebtn, 2, 3);
            tableLayoutPanel1.Controls.Add(eightbtn, 1, 3);
            tableLayoutPanel1.Controls.Add(sevenbtn, 0, 3);
            tableLayoutPanel1.Controls.Add(dividebtn, 3, 2);
            tableLayoutPanel1.Controls.Add(sqrtbtn, 2, 2);
            tableLayoutPanel1.Controls.Add(byThePowerOf2Btn, 1, 2);
            tableLayoutPanel1.Controls.Add(XDividedBy1Btn, 0, 2);
            tableLayoutPanel1.Controls.Add(removeLastOnebtn, 3, 1);
            tableLayoutPanel1.Controls.Add(removeAllbtn, 2, 1);
            tableLayoutPanel1.Controls.Add(removeLastbtn, 1, 1);
            tableLayoutPanel1.Controls.Add(resulttxt, 0, 0);
            tableLayoutPanel1.Controls.Add(percentbtn, 0, 1);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(0, 0);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 7;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 24.5121956F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 12.5813007F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 12.5813007F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 12.5813007F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 12.5813007F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 12.5813007F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 12.5813007F));
            tableLayoutPanel1.Size = new Size(360, 551);
            tableLayoutPanel1.TabIndex = 0;
            tableLayoutPanel1.Paint += tableLayoutPanel1_Paint;
            // 
            // equalbtn
            // 
            equalbtn.Dock = DockStyle.Fill;
            equalbtn.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            equalbtn.Location = new Point(273, 483);
            equalbtn.Name = "equalbtn";
            equalbtn.Size = new Size(84, 65);
            equalbtn.TabIndex = 24;
            equalbtn.Text = "=";
            equalbtn.UseVisualStyleBackColor = true;
            equalbtn.Click += equalbtn_Click;
            // 
            // commabtn
            // 
            commabtn.Dock = DockStyle.Fill;
            commabtn.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            commabtn.Location = new Point(183, 483);
            commabtn.Name = "commabtn";
            commabtn.Size = new Size(84, 65);
            commabtn.TabIndex = 23;
            commabtn.Text = ",";
            commabtn.UseVisualStyleBackColor = true;
            commabtn.Click += commabtn_Click;
            // 
            // zerobtn
            // 
            zerobtn.Dock = DockStyle.Fill;
            zerobtn.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            zerobtn.Location = new Point(93, 483);
            zerobtn.Name = "zerobtn";
            zerobtn.Size = new Size(84, 65);
            zerobtn.TabIndex = 22;
            zerobtn.Text = "0";
            zerobtn.UseVisualStyleBackColor = true;
            zerobtn.Click += zerobtn_Click;
            // 
            // negatebtn
            // 
            negatebtn.Dock = DockStyle.Fill;
            negatebtn.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            negatebtn.Location = new Point(3, 483);
            negatebtn.Name = "negatebtn";
            negatebtn.Size = new Size(84, 65);
            negatebtn.TabIndex = 21;
            negatebtn.Text = "+/-";
            negatebtn.UseVisualStyleBackColor = true;
            negatebtn.Click += negatebtn_Click;
            // 
            // plusbtn
            // 
            plusbtn.Dock = DockStyle.Fill;
            plusbtn.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            plusbtn.Location = new Point(273, 414);
            plusbtn.Name = "plusbtn";
            plusbtn.Size = new Size(84, 63);
            plusbtn.TabIndex = 20;
            plusbtn.Text = "+";
            plusbtn.UseVisualStyleBackColor = true;
            plusbtn.Click += plusbtn_Click;
            // 
            // threebtn
            // 
            threebtn.Dock = DockStyle.Fill;
            threebtn.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            threebtn.Location = new Point(183, 414);
            threebtn.Name = "threebtn";
            threebtn.Size = new Size(84, 63);
            threebtn.TabIndex = 19;
            threebtn.Text = "3";
            threebtn.UseVisualStyleBackColor = true;
            threebtn.Click += threebtn_Click;
            // 
            // twobtn
            // 
            twobtn.Dock = DockStyle.Fill;
            twobtn.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            twobtn.Location = new Point(93, 414);
            twobtn.Name = "twobtn";
            twobtn.Size = new Size(84, 63);
            twobtn.TabIndex = 18;
            twobtn.Text = "2";
            twobtn.UseVisualStyleBackColor = true;
            twobtn.Click += twobtn_Click;
            // 
            // onebtn
            // 
            onebtn.Dock = DockStyle.Fill;
            onebtn.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            onebtn.Location = new Point(3, 414);
            onebtn.Name = "onebtn";
            onebtn.Size = new Size(84, 63);
            onebtn.TabIndex = 17;
            onebtn.Text = "1";
            onebtn.UseVisualStyleBackColor = true;
            onebtn.Click += onebtn_Click;
            // 
            // minusbtn
            // 
            minusbtn.Dock = DockStyle.Fill;
            minusbtn.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            minusbtn.Location = new Point(273, 345);
            minusbtn.Name = "minusbtn";
            minusbtn.Size = new Size(84, 63);
            minusbtn.TabIndex = 16;
            minusbtn.Text = "-";
            minusbtn.UseVisualStyleBackColor = true;
            minusbtn.Click += minusbtn_Click;
            // 
            // sixbtn
            // 
            sixbtn.Dock = DockStyle.Fill;
            sixbtn.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            sixbtn.Location = new Point(183, 345);
            sixbtn.Name = "sixbtn";
            sixbtn.Size = new Size(84, 63);
            sixbtn.TabIndex = 15;
            sixbtn.Text = "6";
            sixbtn.UseVisualStyleBackColor = true;
            sixbtn.Click += sixbtn_Click;
            // 
            // fivebtn
            // 
            fivebtn.Dock = DockStyle.Fill;
            fivebtn.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            fivebtn.Location = new Point(93, 345);
            fivebtn.Name = "fivebtn";
            fivebtn.Size = new Size(84, 63);
            fivebtn.TabIndex = 14;
            fivebtn.Text = "5";
            fivebtn.UseVisualStyleBackColor = true;
            fivebtn.Click += fivebtn_Click;
            // 
            // fourbtn
            // 
            fourbtn.Dock = DockStyle.Fill;
            fourbtn.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            fourbtn.Location = new Point(3, 345);
            fourbtn.Name = "fourbtn";
            fourbtn.Size = new Size(84, 63);
            fourbtn.TabIndex = 13;
            fourbtn.Text = "4";
            fourbtn.UseVisualStyleBackColor = true;
            fourbtn.Click += fourbtn_Click;
            // 
            // multiplicationbtn
            // 
            multiplicationbtn.Dock = DockStyle.Fill;
            multiplicationbtn.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            multiplicationbtn.Location = new Point(273, 276);
            multiplicationbtn.Name = "multiplicationbtn";
            multiplicationbtn.Size = new Size(84, 63);
            multiplicationbtn.TabIndex = 12;
            multiplicationbtn.Text = "×";
            multiplicationbtn.UseVisualStyleBackColor = true;
            multiplicationbtn.Click += multiplicationbtn_Click;
            // 
            // ninebtn
            // 
            ninebtn.Dock = DockStyle.Fill;
            ninebtn.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            ninebtn.Location = new Point(183, 276);
            ninebtn.Name = "ninebtn";
            ninebtn.Size = new Size(84, 63);
            ninebtn.TabIndex = 11;
            ninebtn.Text = "9";
            ninebtn.UseVisualStyleBackColor = true;
            ninebtn.Click += ninebtn_Click;
            // 
            // eightbtn
            // 
            eightbtn.Dock = DockStyle.Fill;
            eightbtn.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            eightbtn.Location = new Point(93, 276);
            eightbtn.Name = "eightbtn";
            eightbtn.Size = new Size(84, 63);
            eightbtn.TabIndex = 10;
            eightbtn.Text = "8";
            eightbtn.UseVisualStyleBackColor = true;
            eightbtn.Click += eightbtn_Click;
            // 
            // sevenbtn
            // 
            sevenbtn.Dock = DockStyle.Fill;
            sevenbtn.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            sevenbtn.Location = new Point(3, 276);
            sevenbtn.Name = "sevenbtn";
            sevenbtn.Size = new Size(84, 63);
            sevenbtn.TabIndex = 9;
            sevenbtn.Text = "7";
            sevenbtn.UseVisualStyleBackColor = true;
            sevenbtn.Click += sevenbtn_Click;
            // 
            // dividebtn
            // 
            dividebtn.Dock = DockStyle.Fill;
            dividebtn.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            dividebtn.Location = new Point(273, 207);
            dividebtn.Name = "dividebtn";
            dividebtn.Size = new Size(84, 63);
            dividebtn.TabIndex = 8;
            dividebtn.Text = "÷";
            dividebtn.UseVisualStyleBackColor = true;
            dividebtn.Click += dividebtn_Click;
            // 
            // sqrtbtn
            // 
            sqrtbtn.Dock = DockStyle.Fill;
            sqrtbtn.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            sqrtbtn.Location = new Point(183, 207);
            sqrtbtn.Name = "sqrtbtn";
            sqrtbtn.Size = new Size(84, 63);
            sqrtbtn.TabIndex = 7;
            sqrtbtn.Text = "²√x";
            sqrtbtn.UseVisualStyleBackColor = true;
            sqrtbtn.Click += sqrtbtn_Click;
            // 
            // byThePowerOf2Btn
            // 
            byThePowerOf2Btn.Dock = DockStyle.Fill;
            byThePowerOf2Btn.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            byThePowerOf2Btn.Location = new Point(93, 207);
            byThePowerOf2Btn.Name = "byThePowerOf2Btn";
            byThePowerOf2Btn.Size = new Size(84, 63);
            byThePowerOf2Btn.TabIndex = 6;
            byThePowerOf2Btn.Text = "x²";
            byThePowerOf2Btn.UseVisualStyleBackColor = true;
            byThePowerOf2Btn.Click += byThePowerOf2Btn_Click;
            // 
            // XDividedBy1Btn
            // 
            XDividedBy1Btn.Dock = DockStyle.Fill;
            XDividedBy1Btn.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            XDividedBy1Btn.Location = new Point(3, 207);
            XDividedBy1Btn.Name = "XDividedBy1Btn";
            XDividedBy1Btn.Size = new Size(84, 63);
            XDividedBy1Btn.TabIndex = 5;
            XDividedBy1Btn.Text = "1/x";
            XDividedBy1Btn.UseVisualStyleBackColor = true;
            XDividedBy1Btn.Click += XDividedBy1Btn_Click;
            // 
            // removeLastOnebtn
            // 
            removeLastOnebtn.Dock = DockStyle.Fill;
            removeLastOnebtn.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            removeLastOnebtn.Location = new Point(273, 138);
            removeLastOnebtn.Name = "removeLastOnebtn";
            removeLastOnebtn.Size = new Size(84, 63);
            removeLastOnebtn.TabIndex = 4;
            removeLastOnebtn.Text = "<=";
            removeLastOnebtn.UseVisualStyleBackColor = true;
            removeLastOnebtn.Click += removeLastOnebtn_Click;
            // 
            // removeAllbtn
            // 
            removeAllbtn.Dock = DockStyle.Fill;
            removeAllbtn.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            removeAllbtn.Location = new Point(183, 138);
            removeAllbtn.Name = "removeAllbtn";
            removeAllbtn.Size = new Size(84, 63);
            removeAllbtn.TabIndex = 3;
            removeAllbtn.Text = "C";
            removeAllbtn.UseVisualStyleBackColor = true;
            removeAllbtn.Click += removeAllbtn_Click;
            // 
            // removeLastbtn
            // 
            removeLastbtn.Dock = DockStyle.Fill;
            removeLastbtn.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            removeLastbtn.Location = new Point(93, 138);
            removeLastbtn.Name = "removeLastbtn";
            removeLastbtn.Size = new Size(84, 63);
            removeLastbtn.TabIndex = 2;
            removeLastbtn.Text = "CE";
            removeLastbtn.UseVisualStyleBackColor = true;
            removeLastbtn.Click += removeLastbtn_Click;
            // 
            // resulttxt
            // 
            tableLayoutPanel1.SetColumnSpan(resulttxt, 4);
            resulttxt.Dock = DockStyle.Fill;
            resulttxt.Font = new Font("Segoe UI", 50F, FontStyle.Regular, GraphicsUnit.Point);
            resulttxt.Location = new Point(3, 3);
            resulttxt.Multiline = true;
            resulttxt.Name = "resulttxt";
            resulttxt.ReadOnly = true;
            resulttxt.Size = new Size(354, 129);
            resulttxt.TabIndex = 0;
            resulttxt.Text = "0";
            resulttxt.TextAlign = HorizontalAlignment.Right;
            resulttxt.KeyDown += resulttxt_KeyDown;
            // 
            // percentbtn
            // 
            percentbtn.Dock = DockStyle.Fill;
            percentbtn.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            percentbtn.Location = new Point(3, 138);
            percentbtn.Name = "percentbtn";
            percentbtn.Size = new Size(84, 63);
            percentbtn.TabIndex = 1;
            percentbtn.Text = "%";
            percentbtn.UseVisualStyleBackColor = true;
            percentbtn.Click += percentbtn_Click;
            // 
            // placeHolderLabelOfScreen
            // 
            placeHolderLabelOfScreen.AutoSize = true;
            placeHolderLabelOfScreen.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point);
            placeHolderLabelOfScreen.ForeColor = SystemColors.ControlDark;
            placeHolderLabelOfScreen.Location = new Point(265, 5);
            placeHolderLabelOfScreen.Name = "placeHolderLabelOfScreen";
            placeHolderLabelOfScreen.Size = new Size(0, 25);
            placeHolderLabelOfScreen.TabIndex = 1;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(360, 551);
            Controls.Add(placeHolderLabelOfScreen);
            Controls.Add(tableLayoutPanel1);
            MinimumSize = new Size(378, 598);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            KeyDown += Form1_KeyDown;
            PreviewKeyDown += Form1_PreviewKeyDown;
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TableLayoutPanel tableLayoutPanel1;
        private TextBox resulttxt;
        private Button equalbtn;
        private Button commabtn;
        private Button zerobtn;
        private Button negatebtn;
        private Button plusbtn;
        private Button threebtn;
        private Button twobtn;
        private Button onebtn;
        private Button minusbtn;
        private Button sixbtn;
        private Button fivebtn;
        private Button fourbtn;
        private Button multiplicationbtn;
        private Button ninebtn;
        private Button eightbtn;
        private Button sevenbtn;
        private Button dividebtn;
        private Button sqrtbtn;
        private Button byThePowerOf2Btn;
        private Button XDividedBy1Btn;
        private Button removeLastOnebtn;
        private Button removeAllbtn;
        private Button removeLastbtn;
        private Button percentbtn;
        private Label placeHolderLabelOfScreen;
    }
}